package prototype;

import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.setmembership.SetMembershipPublicParameters;
import org.cryptimeleon.math.serialization.ObjectRepresentation;
import org.cryptimeleon.math.serialization.Representation;
import org.cryptimeleon.math.serialization.StandaloneRepresentable;
import org.cryptimeleon.math.structures.groups.Group;
import org.cryptimeleon.math.structures.groups.cartesian.GroupElementVector;

public class PartialKnowledgePublicParameters implements StandaloneRepresentable {
	public final Group group;
	public final GroupElementVector crossOrCommitmentBases;
	
	PartialKnowledgePublicParameters(Group group, GroupElementVector crossOrCommitmentBases) {
		this.group = group;
		this.crossOrCommitmentBases = crossOrCommitmentBases;
	}
	
	public PartialKnowledgePublicParameters(Representation repr) {
		group = (Group) repr.obj().get("group").repr().recreateRepresentable();
		crossOrCommitmentBases = group.restoreVector(repr.obj().get("commitmentBases"));
	}
	
	public static PartialKnowledgePublicParameters generateNewParameters(Group group) {
		int numberOfZnWitnesses = 2;
		GroupElementVector crossOrCommitmentBases = group.getUniformlyRandomNonNeutrals(numberOfZnWitnesses + 1);
		return new PartialKnowledgePublicParameters(group, crossOrCommitmentBases);
	}
	
	@Override
	public Representation getRepresentation() {
		ObjectRepresentation repr = new ObjectRepresentation();
		repr.put("group", group.getRepresentation());
		repr.put("commitmentBases", crossOrCommitmentBases.getRepresentation());
		return repr;
	}
}
