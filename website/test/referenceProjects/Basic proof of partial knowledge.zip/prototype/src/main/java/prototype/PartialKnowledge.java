package prototype;

import org.cryptimeleon.craco.protocols.CommonInput;
import org.cryptimeleon.craco.protocols.SecretInput;
import org.cryptimeleon.craco.protocols.arguments.sigma.ChallengeSpace;
import org.cryptimeleon.craco.protocols.arguments.sigma.ZnChallengeSpace;
import org.cryptimeleon.craco.protocols.arguments.sigma.partial.ProofOfPartialKnowledge;
import org.cryptimeleon.craco.protocols.arguments.sigma.partial.ProofOfPartialKnowledge.ProverSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.partial.ProofOfPartialKnowledge.ProverSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.DelegateProtocol;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.LinearStatementFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendFirstValue;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.variables.SchnorrZnVariable;
import org.cryptimeleon.math.expressions.bool.BooleanExpression;
import org.cryptimeleon.math.serialization.Representation;
import org.cryptimeleon.math.structures.cartesian.ExponentExpressionVector;
import org.cryptimeleon.math.structures.groups.Group;
import org.cryptimeleon.math.structures.groups.GroupElement;
import org.cryptimeleon.math.structures.rings.cartesian.RingElementVector;
import org.cryptimeleon.math.structures.rings.zn.Zn.ZnElement;
import org.cryptimeleon.math.structures.rings.zn.Zp;
import org.cryptimeleon.math.structures.rings.zn.Zp.ZpElement;

public class PartialKnowledge extends ProofOfPartialKnowledge {
	protected PartialKnowledgePublicParameters pp;
	protected Group group;
	protected Zp zp;
	
	public PartialKnowledge(Group group, PartialKnowledgePublicParameters pp) {
		this.pp = pp;
		this.group = group;
		this.zp = (Zp) this.group.getZn();
	}
	
	@Override
	protected ProtocolTree provideProtocolTree(CommonInput commonInput, SendFirstValue sendFirstValue) {
		SubprotocolCommonInput subprotocolCommonInput = new SubprotocolCommonInput((PartialKnowledgeCommonInput) commonInput, ((SendFirstValue.AlgebraicSendFirstValue) sendFirstValue).getGroupElement(0));
		return and(
			leaf("Subprotocol1", new Subprotocol1(), subprotocolCommonInput),
			or(
				leaf("Subprotocol2", new Subprotocol2(), subprotocolCommonInput),
				leaf("Subprotocol3", new Subprotocol3(), subprotocolCommonInput)
			)
		);
	}
	
	@Override
	protected ProverSpec provideProverSpec(CommonInput commonInput, SecretInput secretInput, ProverSpecBuilder builder) {
		PartialKnowledgeSecretInput overallSecretInput = (PartialKnowledgeSecretInput) secretInput;
		
		// Commit to all Zn variables
		ZnElement crossOrCommitmentRandomness = zp.getUniformlyRandomElement();
		GroupElement crossOrCommitment = pp.crossOrCommitmentBases.innerProduct(RingElementVector.of(overallSecretInput.x, overallSecretInput.r, crossOrCommitmentRandomness));
		
		// Send this commitment
		builder.setSendFirstValue(new SendFirstValue.AlgebraicSendFirstValue(crossOrCommitment));
		
		// Set up witnesses for subprotocols (which is the secret input for the whole protocol plus the commitment randomness)
		SecretInput subprotocolSecret = new SubprotocolSecretInput(overallSecretInput, crossOrCommitmentRandomness);
		
		builder.putSecretInput("Subprotocol1", subprotocolSecret);
		builder.putSecretInput("Subprotocol2", subprotocolSecret);
		builder.putSecretInput("Subprotocol3", subprotocolSecret);
		
		return builder.build();
	}
	
	@Override
	protected SendFirstValue restoreSendFirstValue(CommonInput commonInput, Representation repr) {
		return new SendFirstValue.AlgebraicSendFirstValue(repr, group);
	}
	
	@Override
	protected SendFirstValue simulateSendFirstValue(CommonInput commonInput) {
		return new SendFirstValue.AlgebraicSendFirstValue(group.getUniformlyRandomElement());
	}
	
	@Override
	protected BooleanExpression provideAdditionalCheck(CommonInput commonInput, SendFirstValue sendFirstValue) {
		return BooleanExpression.TRUE;
	}
	
	@Override
	public ChallengeSpace getChallengeSpace(CommonInput commonInput) {
		return new ZnChallengeSpace(zp);
	}
	
	public class Subprotocol1 extends DelegateProtocol {
		@Override
		protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
			PartialKnowledgeCommonInput input = ((SubprotocolCommonInput) commonInput).commonInput;
			
			//Add variables (witnesses)
			SchnorrZnVariable x = subprotocolSpecBuilder.addZnVariable("x", zp);
			SchnorrZnVariable r = subprotocolSpecBuilder.addZnVariable("r", zp);
			
			//Add statements
			subprotocolSpecBuilder.addSubprotocol("statement1",
				new LinearStatementFragment(input.g.pow(x).op(input.h.pow(r)).isEqualTo(input.C))
			);
			
			// Add proof that the same values are used in this subprotocol as in the others
			SchnorrZnVariable crossOrCommitmentRandomness = subprotocolSpecBuilder.addZnVariable("crossOrCommitmentRandomness", zp);
			subprotocolSpecBuilder.addSubprotocol("orProofConsistency",
				new LinearStatementFragment(
					pp.crossOrCommitmentBases.expr().innerProduct(ExponentExpressionVector.of(x, r, crossOrCommitmentRandomness))
						.isEqualTo(((SubprotocolCommonInput) commonInput).crossOrCommitment)
				)
			);
			
			return subprotocolSpecBuilder.build();
		}
		
		@Override
		protected SendThenDelegateFragment.ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, SendThenDelegateFragment.ProverSpecBuilder proverSpecBuilder) {
			PartialKnowledgeSecretInput witness = ((SubprotocolSecretInput) secretInput).secretInput;
			
			proverSpecBuilder.putWitnessValue("x", witness.x);
			proverSpecBuilder.putWitnessValue("r", witness.r);
			
			proverSpecBuilder.putWitnessValue("crossOrCommitmentRandomness", ((SubprotocolSecretInput) secretInput).crossOrCommitmentRandomness);
			
			return proverSpecBuilder.build();
		}
		
		@Override
		public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
			return new ZnChallengeSpace(zp);
		}
	}
	
	public class Subprotocol2 extends DelegateProtocol {
		@Override
		protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
			PartialKnowledgeCommonInput input = ((SubprotocolCommonInput) commonInput).commonInput;
			
			//Add variables (witnesses)
			SchnorrZnVariable x = subprotocolSpecBuilder.addZnVariable("x", zp);
			SchnorrZnVariable r = subprotocolSpecBuilder.addZnVariable("r", zp);
			
			//Add statements
			subprotocolSpecBuilder.addSubprotocol("statement2",
				new LinearStatementFragment(input.h.pow(r).isEqualTo(input.C_2))
			);
			
			// Add proof that the same values are used in this subprotocol as in the others
			SchnorrZnVariable crossOrCommitmentRandomness = subprotocolSpecBuilder.addZnVariable("crossOrCommitmentRandomness", zp);
			subprotocolSpecBuilder.addSubprotocol("orProofConsistency",
				new LinearStatementFragment(
					pp.crossOrCommitmentBases.expr().innerProduct(ExponentExpressionVector.of(x, r, crossOrCommitmentRandomness))
						.isEqualTo(((SubprotocolCommonInput) commonInput).crossOrCommitment)
				)
			);
			
			return subprotocolSpecBuilder.build();
		}
		
		@Override
		protected SendThenDelegateFragment.ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, SendThenDelegateFragment.ProverSpecBuilder proverSpecBuilder) {
			PartialKnowledgeSecretInput witness = ((SubprotocolSecretInput) secretInput).secretInput;
			
			proverSpecBuilder.putWitnessValue("x", witness.x);
			proverSpecBuilder.putWitnessValue("r", witness.r);
			
			proverSpecBuilder.putWitnessValue("crossOrCommitmentRandomness", ((SubprotocolSecretInput) secretInput).crossOrCommitmentRandomness);
			
			return proverSpecBuilder.build();
		}
		
		@Override
		public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
			return new ZnChallengeSpace(zp);
		}
	}
	
	public class Subprotocol3 extends DelegateProtocol {
		@Override
		protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
			PartialKnowledgeCommonInput input = ((SubprotocolCommonInput) commonInput).commonInput;
			
			//Add variables (witnesses)
			SchnorrZnVariable x = subprotocolSpecBuilder.addZnVariable("x", zp);
			SchnorrZnVariable r = subprotocolSpecBuilder.addZnVariable("r", zp);
			
			//Add statements
			subprotocolSpecBuilder.addSubprotocol("statement3",
				new LinearStatementFragment(input.h.pow(x).isEqualTo(input.C_2))
			);
			
			// Add proof that the same values are used in this subprotocol as in the others
			SchnorrZnVariable crossOrCommitmentRandomness = subprotocolSpecBuilder.addZnVariable("crossOrCommitmentRandomness", zp);
			subprotocolSpecBuilder.addSubprotocol("orProofConsistency",
				new LinearStatementFragment(
					pp.crossOrCommitmentBases.expr().innerProduct(ExponentExpressionVector.of(x, r, crossOrCommitmentRandomness))
						.isEqualTo(((SubprotocolCommonInput) commonInput).crossOrCommitment)
				)
			);
			
			return subprotocolSpecBuilder.build();
		}
		
		@Override
		protected SendThenDelegateFragment.ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, SendThenDelegateFragment.ProverSpecBuilder proverSpecBuilder) {
			PartialKnowledgeSecretInput witness = ((SubprotocolSecretInput) secretInput).secretInput;
			
			proverSpecBuilder.putWitnessValue("x", witness.x);
			proverSpecBuilder.putWitnessValue("r", witness.r);
			
			proverSpecBuilder.putWitnessValue("crossOrCommitmentRandomness", ((SubprotocolSecretInput) secretInput).crossOrCommitmentRandomness);
			
			return proverSpecBuilder.build();
		}
		
		@Override
		public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
			return new ZnChallengeSpace(zp);
		}
	}
	
	public static class PartialKnowledgeCommonInput implements CommonInput {
		public final GroupElement C;
		public final GroupElement C_2;
		public final GroupElement g;
		public final GroupElement h;
		
		public PartialKnowledgeCommonInput(GroupElement C, GroupElement C_2, GroupElement g, GroupElement h) {
			this.C = C;
			this.C_2 = C_2;
			this.g = g;
			this.h = h;
		}
	}
	
	public static class PartialKnowledgeSecretInput implements SecretInput {
		public final ZpElement x;
		public final ZpElement r;
		
		public PartialKnowledgeSecretInput(ZpElement x, ZpElement r) {
			this.x = x;
			this.r = r;
		}
	}
	
	private static class SubprotocolCommonInput implements CommonInput {
		public final PartialKnowledgeCommonInput commonInput;
		public final GroupElement crossOrCommitment;
		
		public SubprotocolCommonInput(PartialKnowledgeCommonInput commonInput, GroupElement crossOrCommitment) {
			this.commonInput = commonInput;
			this.crossOrCommitment = crossOrCommitment;
		}
	}
	
	private static class SubprotocolSecretInput implements SecretInput {
		public final PartialKnowledgeSecretInput secretInput;
		public final ZnElement crossOrCommitmentRandomness;
		
		public SubprotocolSecretInput(PartialKnowledgeSecretInput secretInput, ZnElement crossOrCommitmentRandomness) {
			this.secretInput = secretInput;
			this.crossOrCommitmentRandomness = crossOrCommitmentRandomness;
		}
	}
}
