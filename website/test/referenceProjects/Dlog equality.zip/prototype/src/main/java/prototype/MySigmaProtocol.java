package prototype;

import org.cryptimeleon.craco.protocols.CommonInput;
import org.cryptimeleon.craco.protocols.SecretInput;
import org.cryptimeleon.craco.protocols.arguments.sigma.ZnChallengeSpace;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.DelegateProtocol;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.LinearExponentStatementFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.LinearStatementFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SchnorrFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.ProverSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.ProverSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.variables.SchnorrGroupElemVariable;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.variables.SchnorrZnVariable;
import org.cryptimeleon.math.serialization.Representation;
import org.cryptimeleon.math.structures.groups.Group;
import org.cryptimeleon.math.structures.groups.GroupElement;
import org.cryptimeleon.math.structures.rings.zn.Zn.ZnElement;
import org.cryptimeleon.math.structures.rings.zn.Zp.ZpElement;
import org.cryptimeleon.math.structures.rings.zn.Zp;

public class MySigmaProtocol extends DelegateProtocol {
	protected Group group;
	protected Zp zp;
	
	public MySigmaProtocol(Group group) {
		this.group = group;
		this.zp = (Zp) this.group.getZn();
	}
	
	@Override
	protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
		MySigmaProtocolCommonInput input = (MySigmaProtocolCommonInput) commonInput;
		
		//Add variables (witnesses)
		SchnorrZnVariable k = subprotocolSpecBuilder.addZnVariable("k", zp);
		
		//Add statements
		subprotocolSpecBuilder.addSubprotocol("statement1",
			new LinearStatementFragment(input.b.isEqualTo(input.a.pow(k)))
		);
		subprotocolSpecBuilder.addSubprotocol("statement2",
			new LinearStatementFragment(input.h.isEqualTo(input.g.pow(k)))
		);
		
		
		return subprotocolSpecBuilder.build();
	}
	
	@Override
	protected ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, ProverSpecBuilder proverSpecBuilder) {
		MySigmaProtocolSecretInput witness = (MySigmaProtocolSecretInput) secretInput;
		
		proverSpecBuilder.putWitnessValue("k", witness.k);
		
		
		return proverSpecBuilder.build();
	}
	
	@Override
	public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
		return new ZnChallengeSpace(zp);
	}
	
	public static class MySigmaProtocolCommonInput implements CommonInput {
		public final GroupElement a;
		public final GroupElement b;
		public final GroupElement g;
		public final GroupElement h;
		
		public MySigmaProtocolCommonInput(GroupElement a, GroupElement b, GroupElement g, GroupElement h) {
			this.a = a;
			this.b = b;
			this.g = g;
			this.h = h;
		}
	}
	
	public static class MySigmaProtocolSecretInput implements SecretInput {
		public final ZpElement k;
		
		public MySigmaProtocolSecretInput(ZpElement k) {
			this.k = k;
		}
	}
}
