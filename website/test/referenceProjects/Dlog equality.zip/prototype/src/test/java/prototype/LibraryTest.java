package prototype;

import org.cryptimeleon.craco.protocols.CommonInput;
import org.cryptimeleon.craco.protocols.SecretInput;
import org.cryptimeleon.craco.protocols.arguments.sigma.instance.SigmaProtocolProverInstance;
import org.cryptimeleon.craco.protocols.arguments.sigma.instance.SigmaProtocolVerifierInstance;
import org.cryptimeleon.math.structures.groups.Group;
import org.cryptimeleon.math.structures.groups.GroupElement;
import org.cryptimeleon.math.structures.groups.elliptic.nopairing.Secp256k1;
import org.cryptimeleon.math.structures.rings.zn.Zp;
import org.cryptimeleon.math.structures.rings.zn.Zp.ZpElement;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class LibraryTest {
	@Test
	public void protocolTest() {
		Group group = new Secp256k1();
		Zp zp = (Zp) group.getZn();
		
		// Set witnesses
		ZpElement k = zp.getUniformlyRandomElement();
		
		// Set constants
		GroupElement a = group.getNeutralElement();
		GroupElement b = group.getNeutralElement();
		GroupElement g = group.getNeutralElement();
		GroupElement h = group.getNeutralElement();
		
		// Instantiate protocol and input
		MySigmaProtocol protocol = new MySigmaProtocol(group);
		
		CommonInput commonInput = new MySigmaProtocol.MySigmaProtocolCommonInput(a, b, g, h);
		SecretInput secretInput = new MySigmaProtocol.MySigmaProtocolSecretInput(k);
		
		SigmaProtocolProverInstance prover = protocol.getProverInstance(commonInput, secretInput);
		SigmaProtocolVerifierInstance verifier = protocol.getVerifierInstance(commonInput);
		
		protocol.runProtocolLocally(prover, verifier);
		assertTrue(verifier.hasTerminated());
		assertTrue(verifier.isAccepting());
		if (verifier.isAccepting())
		    System.out.println("Yay, the protocol worked!");
	}
}
