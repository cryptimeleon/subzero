package prototype;

import org.cryptimeleon.craco.protocols.CommonInput;
import org.cryptimeleon.craco.protocols.SecretInput;
import org.cryptimeleon.craco.protocols.arguments.sigma.ZnChallengeSpace;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.DelegateProtocol;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.LinearExponentStatementFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.LinearStatementFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SchnorrFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.ProverSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.ProverSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.setmembership.TwoSidedRangeProof;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.variables.SchnorrGroupElemVariable;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.variables.SchnorrZnVariable;
import org.cryptimeleon.math.serialization.Representation;
import org.cryptimeleon.math.structures.groups.Group;
import org.cryptimeleon.math.structures.groups.GroupElement;
import org.cryptimeleon.math.structures.groups.elliptic.BilinearGroup;
import org.cryptimeleon.math.structures.rings.zn.Zn.ZnElement;
import org.cryptimeleon.math.structures.rings.zn.Zp.ZpElement;
import org.cryptimeleon.math.structures.rings.zn.Zp;

public class PedersenCommitmentWithRangeProof extends DelegateProtocol {
	protected PedersenCommitmentWithRangeProofPublicParameters pp;
	protected BilinearGroup bilinearGroup;
	protected Zp zp;
	protected final GroupElement g;
	protected final GroupElement h_1;
	protected final GroupElement h_2;
	
	public PedersenCommitmentWithRangeProof(BilinearGroup bilinearGroup, PedersenCommitmentWithRangeProofPublicParameters pp, GroupElement g, GroupElement h_1, GroupElement h_2) {
		this.pp = pp;
		this.bilinearGroup = bilinearGroup;
		this.zp = (Zp) this.bilinearGroup.getZn();
		this.g = g;
		this.h_1 = h_1;
		this.h_2 = h_2;
	}
	
	@Override
	protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
		PedersenCommitmentWithRangeProofCommonInput input = (PedersenCommitmentWithRangeProofCommonInput) commonInput;
		
		//Add variables (witnesses)
		SchnorrZnVariable m_1 = subprotocolSpecBuilder.addZnVariable("m_1", zp);
		SchnorrZnVariable m_2 = subprotocolSpecBuilder.addZnVariable("m_2", zp);
		SchnorrZnVariable r = subprotocolSpecBuilder.addZnVariable("r", zp);
		
		//Add statements
		subprotocolSpecBuilder.addSubprotocol("statement1",
			new LinearStatementFragment(input.C_1.isEqualTo(h_1.pow(m_1).op(h_2.pow(m_2)).op(g.pow(r))))
		);
		subprotocolSpecBuilder.addSubprotocol("statement2",
			new TwoSidedRangeProof(m_1.add(m_2), zp.valueOf(0), zp.valueOf(100), pp.rangeProofpp)
		);
		
		
		return subprotocolSpecBuilder.build();
	}
	
	@Override
	protected ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, ProverSpecBuilder proverSpecBuilder) {
		PedersenCommitmentWithRangeProofSecretInput witness = (PedersenCommitmentWithRangeProofSecretInput) secretInput;
		
		proverSpecBuilder.putWitnessValue("m_1", witness.m_1);
		proverSpecBuilder.putWitnessValue("m_2", witness.m_2);
		proverSpecBuilder.putWitnessValue("r", witness.r);
		
		
		return proverSpecBuilder.build();
	}
	
	@Override
	public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
		return new ZnChallengeSpace(zp);
	}
	
	public static class PedersenCommitmentWithRangeProofCommonInput implements CommonInput {
		public final GroupElement C_1;
		
		public PedersenCommitmentWithRangeProofCommonInput(GroupElement C_1) {
			this.C_1 = C_1;
		}
	}
	
	public static class PedersenCommitmentWithRangeProofSecretInput implements SecretInput {
		public final ZpElement m_1;
		public final ZpElement m_2;
		public final ZpElement r;
		
		public PedersenCommitmentWithRangeProofSecretInput(ZpElement m_1, ZpElement m_2, ZpElement r) {
			this.m_1 = m_1;
			this.m_2 = m_2;
			this.r = r;
		}
	}
}
