package prototype;

import org.cryptimeleon.craco.protocols.CommonInput;
import org.cryptimeleon.craco.protocols.SecretInput;
import org.cryptimeleon.craco.protocols.arguments.sigma.instance.SigmaProtocolProverInstance;
import org.cryptimeleon.craco.protocols.arguments.sigma.instance.SigmaProtocolVerifierInstance;
import org.cryptimeleon.math.structures.groups.Group;
import org.cryptimeleon.math.structures.groups.GroupElement;
import org.cryptimeleon.math.structures.groups.elliptic.BilinearGroup;
import org.cryptimeleon.math.structures.groups.elliptic.type3.bn.BarretoNaehrigBilinearGroup;
import org.cryptimeleon.math.structures.rings.zn.Zp.ZpElement;
import org.cryptimeleon.math.structures.rings.zn.Zp;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class LibraryTest {
	@Test
	public void protocolTest() {
		BilinearGroup bilinearGroup = new BarretoNaehrigBilinearGroup(80);
		PedersenCommitmentWithRangeProofPublicParameters pp = PedersenCommitmentWithRangeProofPublicParameters.generateNewParameters(bilinearGroup);
		Group groupG1 = bilinearGroup.getG1();
		Zp zp = (Zp) groupG1.getZn();
		
		// Set public parameters
		GroupElement g = groupG1.getNeutralElement();
		GroupElement h_1 = groupG1.getNeutralElement();
		GroupElement h_2 = groupG1.getNeutralElement();
		
		// Set witnesses
		ZpElement m_1 = zp.valueOf(0); // Change this value so that it satisfies all constraints on the witness
		ZpElement m_2 = zp.valueOf(0); // Change this value so that it satisfies all constraints on the witness
		ZpElement r = zp.getUniformlyRandomElement();
		
		// Set constants
		GroupElement C_1 = groupG1.getNeutralElement();
		
		// Instantiate protocol and input
		PedersenCommitmentWithRangeProof protocol = new PedersenCommitmentWithRangeProof(bilinearGroup, pp, g, h_1, h_2);
		
		CommonInput commonInput = new PedersenCommitmentWithRangeProof.PedersenCommitmentWithRangeProofCommonInput(C_1);
		SecretInput secretInput = new PedersenCommitmentWithRangeProof.PedersenCommitmentWithRangeProofSecretInput(m_1, m_2, r);
		
		SigmaProtocolProverInstance prover = protocol.getProverInstance(commonInput, secretInput);
		SigmaProtocolVerifierInstance verifier = protocol.getVerifierInstance(commonInput);
		
		protocol.runProtocolLocally(prover, verifier);
		assertTrue(verifier.hasTerminated());
		assertTrue(verifier.isAccepting());
		if (verifier.isAccepting())
		    System.out.println("Yay, the protocol worked!");
	}
}
