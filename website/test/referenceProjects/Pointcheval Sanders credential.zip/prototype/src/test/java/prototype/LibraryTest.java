package prototype;

import org.cryptimeleon.craco.protocols.CommonInput;
import org.cryptimeleon.craco.protocols.SecretInput;
import org.cryptimeleon.craco.protocols.arguments.sigma.instance.SigmaProtocolProverInstance;
import org.cryptimeleon.craco.protocols.arguments.sigma.instance.SigmaProtocolVerifierInstance;
import org.cryptimeleon.math.structures.groups.Group;
import org.cryptimeleon.math.structures.groups.GroupElement;
import org.cryptimeleon.math.structures.groups.elliptic.BilinearGroup;
import org.cryptimeleon.math.structures.groups.elliptic.type3.bn.BarretoNaehrigBilinearGroup;
import org.cryptimeleon.math.structures.rings.zn.Zp;
import org.cryptimeleon.math.structures.rings.zn.Zp.ZpElement;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class LibraryTest {
	@Test
	public void protocolTest() {
		BilinearGroup bilinearGroup = new BarretoNaehrigBilinearGroup(80);
		PointchevalSandersCredentialShowingPublicParameters pp = PointchevalSandersCredentialShowingPublicParameters.generateNewParameters(bilinearGroup);
		Group groupG1 = bilinearGroup.getG1();
		Group groupG2 = bilinearGroup.getG2();
		Group groupGT = bilinearGroup.getGT();
		Zp zp = (Zp) groupG1.getZn();
		
		// Set witnesses
		ZpElement age = zp.valueOf(0); // Change this value so that it satisfies all constraints on the witness
		ZpElement pos = zp.valueOf(0); // Change this value so that it satisfies all constraints on the witness
		ZpElement r = zp.getUniformlyRandomElement();
		
		// Set constants
		GroupElement XTilde = groupG2.getNeutralElement();
		GroupElement YTilde_1 = groupG2.getNeutralElement();
		GroupElement YTilde_2 = groupG2.getNeutralElement();
		GroupElement gTilde = groupG2.getNeutralElement();
		GroupElement sigma_1Prime = groupG1.getNeutralElement();
		GroupElement sigma_2Prime = groupG1.getNeutralElement();
		
		// Instantiate protocol and input
		PointchevalSandersCredentialShowing protocol = new PointchevalSandersCredentialShowing(bilinearGroup, pp);
		
		CommonInput commonInput = new PointchevalSandersCredentialShowing.PointchevalSandersCredentialShowingCommonInput(XTilde, YTilde_1, YTilde_2, gTilde, sigma_1Prime, sigma_2Prime);
		SecretInput secretInput = new PointchevalSandersCredentialShowing.PointchevalSandersCredentialShowingSecretInput(age, pos, r);
		
		SigmaProtocolProverInstance prover = protocol.getProverInstance(commonInput, secretInput);
		SigmaProtocolVerifierInstance verifier = protocol.getVerifierInstance(commonInput);
		
		protocol.runProtocolLocally(prover, verifier);
		assertTrue(verifier.hasTerminated());
		assertTrue(verifier.isAccepting());
		if (verifier.isAccepting())
		    System.out.println("Yay, the protocol worked!");
	}
}
