package prototype;

import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.setmembership.SetMembershipPublicParameters;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.setmembership.TwoSidedRangeProof;
import org.cryptimeleon.math.serialization.ObjectRepresentation;
import org.cryptimeleon.math.serialization.Representation;
import org.cryptimeleon.math.serialization.StandaloneRepresentable;
import org.cryptimeleon.math.structures.groups.cartesian.GroupElementVector;
import org.cryptimeleon.math.structures.groups.elliptic.BilinearGroup;
import org.cryptimeleon.math.structures.groups.elliptic.type3.bn.BarretoNaehrigBilinearGroup;

public class PointchevalSandersCredentialShowingPublicParameters implements StandaloneRepresentable {
	public final BilinearGroup bilinearGroup;
	public final SetMembershipPublicParameters rangeProofpp;
	public final GroupElementVector crossOrCommitmentBases;
	
	PointchevalSandersCredentialShowingPublicParameters(BilinearGroup bilinearGroup, SetMembershipPublicParameters rangeProofpp, GroupElementVector crossOrCommitmentBases) {
		this.bilinearGroup = bilinearGroup;
		this.rangeProofpp = rangeProofpp;
		this.crossOrCommitmentBases = crossOrCommitmentBases;
	}
	
	public PointchevalSandersCredentialShowingPublicParameters(Representation repr) {
		bilinearGroup = (BilinearGroup) repr.obj().get("bilinearGroup").repr().recreateRepresentable();
		rangeProofpp = new SetMembershipPublicParameters(bilinearGroup, repr.obj().get("setMembershipPp"));
		crossOrCommitmentBases = bilinearGroup.getG1().restoreVector(repr.obj().get("commitmentBases"));
	}
	
	public static PointchevalSandersCredentialShowingPublicParameters generateNewParameters(BilinearGroup bilinearGroup) {
		SetMembershipPublicParameters rangeProof1pp = TwoSidedRangeProof.generatePublicParameters(bilinearGroup, 100);
		int numberOfZnWitnesses = 3;
		GroupElementVector crossOrCommitmentBases = bilinearGroup.getG1().getUniformlyRandomNonNeutrals(numberOfZnWitnesses + 1);
		return new PointchevalSandersCredentialShowingPublicParameters(bilinearGroup, rangeProof1pp, crossOrCommitmentBases);
	}
	
	@Override
	public Representation getRepresentation() {
		ObjectRepresentation repr = new ObjectRepresentation();
		repr.put("bilinearGroup", bilinearGroup.getRepresentation());
		repr.put("rangeProofpp", rangeProofpp.getRepresentation());
		repr.put("commitmentBases", crossOrCommitmentBases.getRepresentation());
		return repr;
	}
}
