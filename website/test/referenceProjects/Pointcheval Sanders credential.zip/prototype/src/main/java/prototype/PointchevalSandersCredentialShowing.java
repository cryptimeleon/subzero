package prototype;

import org.cryptimeleon.craco.protocols.CommonInput;
import org.cryptimeleon.craco.protocols.SecretInput;
import org.cryptimeleon.craco.protocols.arguments.sigma.ChallengeSpace;
import org.cryptimeleon.craco.protocols.arguments.sigma.ZnChallengeSpace;
import org.cryptimeleon.craco.protocols.arguments.sigma.partial.ProofOfPartialKnowledge;
import org.cryptimeleon.craco.protocols.arguments.sigma.partial.ProofOfPartialKnowledge.ProverSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.partial.ProofOfPartialKnowledge.ProverSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.DelegateProtocol;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.LinearExponentStatementFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.LinearStatementFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendFirstValue;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpec;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.SendThenDelegateFragment.SubprotocolSpecBuilder;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.setmembership.TwoSidedRangeProof;
import org.cryptimeleon.craco.protocols.arguments.sigma.schnorr.variables.SchnorrZnVariable;
import org.cryptimeleon.math.expressions.bool.BooleanExpression;
import org.cryptimeleon.math.serialization.Representation;
import org.cryptimeleon.math.structures.cartesian.ExponentExpressionVector;
import org.cryptimeleon.math.structures.groups.GroupElement;
import org.cryptimeleon.math.structures.groups.elliptic.BilinearGroup;
import org.cryptimeleon.math.structures.groups.elliptic.BilinearMap;
import org.cryptimeleon.math.structures.rings.cartesian.RingElementVector;
import org.cryptimeleon.math.structures.rings.zn.Zn.ZnElement;
import org.cryptimeleon.math.structures.rings.zn.Zp;
import org.cryptimeleon.math.structures.rings.zn.Zp.ZpElement;

public class PointchevalSandersCredentialShowing extends ProofOfPartialKnowledge {
	protected PointchevalSandersCredentialShowingPublicParameters pp;
	protected BilinearGroup bilinearGroup;
	protected Zp zp;
	protected BilinearMap e;
	
	public PointchevalSandersCredentialShowing(BilinearGroup bilinearGroup, PointchevalSandersCredentialShowingPublicParameters pp) {
		this.pp = pp;
		this.bilinearGroup = bilinearGroup;
		this.zp = (Zp) this.bilinearGroup.getZn();
		this.e = bilinearGroup.getBilinearMap();
	}
	
	@Override
	protected ProtocolTree provideProtocolTree(CommonInput commonInput, SendFirstValue sendFirstValue) {
		SubprotocolCommonInput subprotocolCommonInput = new SubprotocolCommonInput((PointchevalSandersCredentialShowingCommonInput) commonInput, ((SendFirstValue.AlgebraicSendFirstValue) sendFirstValue).getGroupElement(0));
		return and(
			leaf("Subprotocol1", new Subprotocol1(), subprotocolCommonInput),
			or(
				leaf("Subprotocol2", new Subprotocol2(), subprotocolCommonInput),
				leaf("Subprotocol3", new Subprotocol3(), subprotocolCommonInput)
			)
		);
	}
	
	@Override
	protected ProverSpec provideProverSpec(CommonInput commonInput, SecretInput secretInput, ProverSpecBuilder builder) {
		PointchevalSandersCredentialShowingSecretInput overallSecretInput = (PointchevalSandersCredentialShowingSecretInput) secretInput;
		
		// Commit to all Zn variables
		ZnElement crossOrCommitmentRandomness = zp.getUniformlyRandomElement();
		GroupElement crossOrCommitment = pp.crossOrCommitmentBases.innerProduct(RingElementVector.of(overallSecretInput.age, overallSecretInput.pos, overallSecretInput.r, crossOrCommitmentRandomness));
		
		// Send this commitment
		builder.setSendFirstValue(new SendFirstValue.AlgebraicSendFirstValue(crossOrCommitment));
		
		// Set up witnesses for subprotocols (which is the secret input for the whole protocol plus the commitment randomness)
		SecretInput subprotocolSecret = new SubprotocolSecretInput(overallSecretInput, crossOrCommitmentRandomness);
		
		builder.putSecretInput("Subprotocol1", subprotocolSecret);
		builder.putSecretInput("Subprotocol2", subprotocolSecret);
		builder.putSecretInput("Subprotocol3", subprotocolSecret);
		
		return builder.build();
	}
	
	@Override
	protected SendFirstValue restoreSendFirstValue(CommonInput commonInput, Representation repr) {
		return new SendFirstValue.AlgebraicSendFirstValue(repr, bilinearGroup.getG1());
	}
	
	@Override
	protected SendFirstValue simulateSendFirstValue(CommonInput commonInput) {
		return new SendFirstValue.AlgebraicSendFirstValue(bilinearGroup.getG1().getUniformlyRandomElement());
	}
	
	@Override
	protected BooleanExpression provideAdditionalCheck(CommonInput commonInput, SendFirstValue sendFirstValue) {
		return BooleanExpression.TRUE;
	}
	
	@Override
	public ChallengeSpace getChallengeSpace(CommonInput commonInput) {
		return new ZnChallengeSpace(zp);
	}
	
	public class Subprotocol1 extends DelegateProtocol {
		@Override
		protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
			PointchevalSandersCredentialShowingCommonInput input = ((SubprotocolCommonInput) commonInput).commonInput;
			
			//Add variables (witnesses)
			SchnorrZnVariable age = subprotocolSpecBuilder.addZnVariable("age", zp);
			SchnorrZnVariable pos = subprotocolSpecBuilder.addZnVariable("pos", zp);
			SchnorrZnVariable r = subprotocolSpecBuilder.addZnVariable("r", zp);
			
			//Add statements
			subprotocolSpecBuilder.addSubprotocol("statement1",
				new LinearStatementFragment(e.applyExpr(input.sigma_1Prime, input.XTilde).op(e.applyExpr(input.sigma_1Prime, input.YTilde_1.pow(age).op(input.YTilde_2.pow(pos)))).op(e.applyExpr(input.sigma_1Prime, input.gTilde).pow(r)).isEqualTo(e.applyExpr(input.sigma_2Prime, input.gTilde)))
			);
			
			// Add proof that the same values are used in this subprotocol as in the others
			SchnorrZnVariable crossOrCommitmentRandomness = subprotocolSpecBuilder.addZnVariable("crossOrCommitmentRandomness", zp);
			subprotocolSpecBuilder.addSubprotocol("orProofConsistency",
				new LinearStatementFragment(
					pp.crossOrCommitmentBases.expr().innerProduct(ExponentExpressionVector.of(age, pos, r, crossOrCommitmentRandomness))
						.isEqualTo(((SubprotocolCommonInput) commonInput).crossOrCommitment)
				)
			);
			
			return subprotocolSpecBuilder.build();
		}
		
		@Override
		protected SendThenDelegateFragment.ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, SendThenDelegateFragment.ProverSpecBuilder proverSpecBuilder) {
			PointchevalSandersCredentialShowingSecretInput witness = ((SubprotocolSecretInput) secretInput).secretInput;
			
			proverSpecBuilder.putWitnessValue("age", witness.age);
			proverSpecBuilder.putWitnessValue("pos", witness.pos);
			proverSpecBuilder.putWitnessValue("r", witness.r);
			
			proverSpecBuilder.putWitnessValue("crossOrCommitmentRandomness", ((SubprotocolSecretInput) secretInput).crossOrCommitmentRandomness);
			
			return proverSpecBuilder.build();
		}
		
		@Override
		public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
			return new ZnChallengeSpace(zp);
		}
	}
	
	public class Subprotocol2 extends DelegateProtocol {
		@Override
		protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
			PointchevalSandersCredentialShowingCommonInput input = ((SubprotocolCommonInput) commonInput).commonInput;
			
			//Add variables (witnesses)
			SchnorrZnVariable age = subprotocolSpecBuilder.addZnVariable("age", zp);
			SchnorrZnVariable pos = subprotocolSpecBuilder.addZnVariable("pos", zp);
			SchnorrZnVariable r = subprotocolSpecBuilder.addZnVariable("r", zp);
			
			//Add statements
			subprotocolSpecBuilder.addSubprotocol("statement2",
				new TwoSidedRangeProof(age, zp.valueOf(0), zp.valueOf(17), pp.rangeProofpp)
			);
			
			// Add proof that the same values are used in this subprotocol as in the others
			SchnorrZnVariable crossOrCommitmentRandomness = subprotocolSpecBuilder.addZnVariable("crossOrCommitmentRandomness", zp);
			subprotocolSpecBuilder.addSubprotocol("orProofConsistency",
				new LinearStatementFragment(
					pp.crossOrCommitmentBases.expr().innerProduct(ExponentExpressionVector.of(age, pos, r, crossOrCommitmentRandomness))
						.isEqualTo(((SubprotocolCommonInput) commonInput).crossOrCommitment)
				)
			);
			
			return subprotocolSpecBuilder.build();
		}
		
		@Override
		protected SendThenDelegateFragment.ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, SendThenDelegateFragment.ProverSpecBuilder proverSpecBuilder) {
			PointchevalSandersCredentialShowingSecretInput witness = ((SubprotocolSecretInput) secretInput).secretInput;
			
			proverSpecBuilder.putWitnessValue("age", witness.age);
			proverSpecBuilder.putWitnessValue("pos", witness.pos);
			proverSpecBuilder.putWitnessValue("r", witness.r);
			
			proverSpecBuilder.putWitnessValue("crossOrCommitmentRandomness", ((SubprotocolSecretInput) secretInput).crossOrCommitmentRandomness);
			
			return proverSpecBuilder.build();
		}
		
		@Override
		public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
			return new ZnChallengeSpace(zp);
		}
	}
	
	public class Subprotocol3 extends DelegateProtocol {
		@Override
		protected SubprotocolSpec provideSubprotocolSpec(CommonInput commonInput, SubprotocolSpecBuilder subprotocolSpecBuilder) {
			PointchevalSandersCredentialShowingCommonInput input = ((SubprotocolCommonInput) commonInput).commonInput;
			
			//Add variables (witnesses)
			SchnorrZnVariable age = subprotocolSpecBuilder.addZnVariable("age", zp);
			SchnorrZnVariable pos = subprotocolSpecBuilder.addZnVariable("pos", zp);
			SchnorrZnVariable r = subprotocolSpecBuilder.addZnVariable("r", zp);
			
			//Add statements
			subprotocolSpecBuilder.addSubprotocol("statement3",
				new LinearExponentStatementFragment(pos.isEqualTo(zp.valueOf(17)), zp)
			);
			
			// Add proof that the same values are used in this subprotocol as in the others
			SchnorrZnVariable crossOrCommitmentRandomness = subprotocolSpecBuilder.addZnVariable("crossOrCommitmentRandomness", zp);
			subprotocolSpecBuilder.addSubprotocol("orProofConsistency",
				new LinearStatementFragment(
					pp.crossOrCommitmentBases.expr().innerProduct(ExponentExpressionVector.of(age, pos, r, crossOrCommitmentRandomness))
						.isEqualTo(((SubprotocolCommonInput) commonInput).crossOrCommitment)
				)
			);
			
			return subprotocolSpecBuilder.build();
		}
		
		@Override
		protected SendThenDelegateFragment.ProverSpec provideProverSpecWithNoSendFirst(CommonInput commonInput, SecretInput secretInput, SendThenDelegateFragment.ProverSpecBuilder proverSpecBuilder) {
			PointchevalSandersCredentialShowingSecretInput witness = ((SubprotocolSecretInput) secretInput).secretInput;
			
			proverSpecBuilder.putWitnessValue("age", witness.age);
			proverSpecBuilder.putWitnessValue("pos", witness.pos);
			proverSpecBuilder.putWitnessValue("r", witness.r);
			
			proverSpecBuilder.putWitnessValue("crossOrCommitmentRandomness", ((SubprotocolSecretInput) secretInput).crossOrCommitmentRandomness);
			
			return proverSpecBuilder.build();
		}
		
		@Override
		public ZnChallengeSpace getChallengeSpace(CommonInput commonInput) {
			return new ZnChallengeSpace(zp);
		}
	}
	
	public static class PointchevalSandersCredentialShowingCommonInput implements CommonInput {
		public final GroupElement XTilde;
		public final GroupElement YTilde_1;
		public final GroupElement YTilde_2;
		public final GroupElement gTilde;
		public final GroupElement sigma_1Prime;
		public final GroupElement sigma_2Prime;
		
		public PointchevalSandersCredentialShowingCommonInput(GroupElement XTilde, GroupElement YTilde_1, GroupElement YTilde_2, GroupElement gTilde, GroupElement sigma_1Prime, GroupElement sigma_2Prime) {
			this.XTilde = XTilde;
			this.YTilde_1 = YTilde_1;
			this.YTilde_2 = YTilde_2;
			this.gTilde = gTilde;
			this.sigma_1Prime = sigma_1Prime;
			this.sigma_2Prime = sigma_2Prime;
		}
	}
	
	public static class PointchevalSandersCredentialShowingSecretInput implements SecretInput {
		public final ZpElement age;
		public final ZpElement pos;
		public final ZpElement r;
		
		public PointchevalSandersCredentialShowingSecretInput(ZpElement age, ZpElement pos, ZpElement r) {
			this.age = age;
			this.pos = pos;
			this.r = r;
		}
	}
	
	private static class SubprotocolCommonInput implements CommonInput {
		public final PointchevalSandersCredentialShowingCommonInput commonInput;
		public final GroupElement crossOrCommitment;
		
		public SubprotocolCommonInput(PointchevalSandersCredentialShowingCommonInput commonInput, GroupElement crossOrCommitment) {
			this.commonInput = commonInput;
			this.crossOrCommitment = crossOrCommitment;
		}
	}
	
	private static class SubprotocolSecretInput implements SecretInput {
		public final PointchevalSandersCredentialShowingSecretInput secretInput;
		public final ZnElement crossOrCommitmentRandomness;
		
		public SubprotocolSecretInput(PointchevalSandersCredentialShowingSecretInput secretInput, ZnElement crossOrCommitmentRandomness) {
			this.secretInput = secretInput;
			this.crossOrCommitmentRandomness = crossOrCommitmentRandomness;
		}
	}
}
